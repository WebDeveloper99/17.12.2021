import React, { Component } from "react";
import "../Main/Main.css";

class Main extends Component {
  constructor() {
    super();
    this.state = {
      id: 3,
      activ: null,
      change: 99,
      db: 0,
      userArray: [
        {
          userId: 1,
          userName: "Eldor",
          userSurname: "Eshmanov",
          userStatus: "Talaba",
          userUniversity: "TATU",
          userFaculty: "DIF",
          userContact: "90 7201780",
        },
        {
          userId: 2,
          userName: "Eldor",
          userSurname: "Eshmanov",
          userStatus: "Talaba",
          userUniversity: "TATU",
          userFaculty: "DIF",
          userContact: "90 7201780",
        },
      ],
    };
  }

  render() {
    const onAdd = () => {
      let name = document.getElementById("name").value;
      let surname = document.getElementById("surname").value;
      let status = document.getElementById("status").value;
      let university = document.getElementById("university").value;
      let faculty = document.getElementById("faculty").value;
      let contact = document.getElementById("contact").value;

      if (
        name &&
        surname &&
        status &&
        university &&
        faculty &&
        contact !== ""
      ) {
        const obj = {
          id: this.state.id++,
          userName: name,
          userSurname: surname,
          userStatus: status,
          userUniversity: university,
          userFaculty: faculty,
          userContact: contact,
        };

        this.state.userArray.push(obj);

        console.log(this.state.userArray);

        document.getElementById("name").value = "";
        document.getElementById("surname").value = "";
        document.getElementById("status").value = "";
        document.getElementById("university").value = "";
        document.getElementById("faculty").value = "";
        document.getElementById("contact").value = "";
      } else {
        alert("Fill in the rows completely");
      }
    };

    // -----------------------------onEdit----------------------------------
    const onEdit = (id) => {
      this.setState({
        activ: id,
      });
    };
    // -----------------------------onDelete----------------------------------
    const onDelete = (id) => {
      let result = this.state.userArray.filter((item) => item.userId !== id);
      this.setState({
        userArray: result,
      });
    };
    // -----------------------------onSubmit----------------------------------
    const onSubmit = (res) => {
      res === 99 &&
        this.setState({
          change: res,
        });
      res === 77 &&
        this.setState({
          change: res,
        });
    };
    // -----------------------------myFunc----------------------------------

    const myFunc = (dbId) => {
      dbId % 2 === 0
        ? this.setState({
            db: this.state.db + 1,
          })
        : this.setState({
            db: this.state.db - 1,
          });
      console.log(this.state.db);
    };

    return (
      <div className="Main">
        <div className="Main-Container">
          <div>
            <input id="name" placeholder="name ..." type="text" />
            <input id="surname" placeholder="surname ..." type="text" />
            <input id="status" placeholder="status ..." type="text" />
            <input id="university" placeholder="university ..." type="text" />
            <input id="faculty" placeholder="faculty ..." type="text" />
            <input id="contact" placeholder="contact ..." type="text" />
          </div>

          <button onClick={() => onAdd()}>Add</button>

          <br />
          <br />

          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Surname</th>
                <th>Status</th>
                <th>University</th>
                <th>Faculty</th>
                <th>Contact</th>
                <th>Buttons</th>
              </tr>
            </thead>

            <tbody>
              {this.state.userArray.map((value, index) => {
                return (
                  <tr key={index}>
                    <td>
                      {this.state.activ === value.userId ? (
                        <input defaultValue={value.userId} />
                      ) : (
                        value.userId
                      )}
                    </td>
                    <td>
                      {this.state.activ === value.userId ? (
                        <input defaultValue={value.userName} />
                      ) : (
                        value.userName
                      )}
                    </td>
                    <td>
                      {this.state.activ === value.userId ? (
                        <input defaultValue={value.userSurname} />
                      ) : (
                        value.userSurname
                      )}
                    </td>
                    <td>
                      {this.state.activ === value.userId ? (
                        <input defaultValue={value.userStatus} />
                      ) : (
                        value.userStatus
                      )}
                    </td>
                    <td>
                      {this.state.activ === value.userId ? (
                        <input defaultValue={value.userUniversity} />
                      ) : (
                        value.userUniversity
                      )}
                    </td>
                    <td>
                      {this.state.activ === value.userId ? (
                        <input defaultValue={value.userFaculty} />
                      ) : (
                        value.userFaculty
                      )}
                    </td>
                    <td>
                      {this.state.activ === value.userId ? (
                        <input defaultValue={value.userContact} />
                      ) : (
                        value.userContact
                      )}
                    </td>
                    <td>
                      <button onClick={() => onDelete(value.userId)}>
                        Delete
                      </button>
                      <button onClick={() => onEdit(value.userId)}>
                        {this.state.activ === value.userId ? "Save" : "Edit"}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          <div
            className={` signIn-container ${
              this.state.db % 2 == 0 ? "kun" : "tun"
            } `}
            id={`${this.state.change === 99 ? "sign" : ""}`}
          >
            <div className="signIn-box">
              <p></p>
              <div className={`signIn-main ${
                  this.state.db % 2 == 0 ? "main-kun" : "main-tun"
                }` }>
                <label htmlFor="email">Enter Email</label>
                <input
                  id="email"
                  placeholder="eshmanoveldor@gmail.com"
                  type="text"
                />
                <label htmlFor="pass">Enter Password</label>
                <input id="pass" placeholder="password" type="text" />
                <button type="submit" onClick={() => onSubmit(99)}>
                  Sign In
                </button>
                <input
                  type="checkbox"
                  className=""
                  onClick={() => myFunc(this.state.db)}
                />
              </div>
            </div>
          </div>

          <div
            className={` signUp-container ${
              this.state.db % 2 == 0 ? "kun" : "tun"
            } `}
            id={`${this.state.change === 77 ? "sign" : ""}`}
          >
            <div className="signUp-box">
              <p></p>
              <div
                className={`signUp-main ${
                  this.state.db % 2 == 0 ? "main-kun" : "main-tun"
                }`}
              >
                <label htmlFor="emailll">Enter Email</label>
                <input
                  id="emailll"
                  placeholder="eshmanoveldor@gmail.com"
                  type="text"
                />
                <label htmlFor="passssss">Enter Password</label>
                <input id="passssss" placeholder="password" type="text" />
                <button type="submit" onClick={() => onSubmit(77)}>
                  Sign Up
                </button>
                <input type="checkbox" onClick={() => myFunc(this.state.db)} />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Main;
