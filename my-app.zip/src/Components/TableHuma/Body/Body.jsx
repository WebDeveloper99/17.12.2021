


import React, { Component } from 'react'
import '../Body/Body.css'
import SectionRight from './SectionRight/SectionRight'
import SectionLeft from './SectionLeft/SectionLeft'
import Main from './Main/Main'

class Body extends Component {
    render() {
        return (
            <div className='Body'>
                <SectionLeft/>
                <Main />
                <SectionRight/>
            </div>
        )
    }
}

export default Body