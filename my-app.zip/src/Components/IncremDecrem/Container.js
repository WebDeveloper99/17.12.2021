import React, { Component } from "react";
import "../IncremDecrem/Container.css";

class Container extends Component {
  constructor(props) {
    super(props);

    this.state = {
      count: 4,
      name: "",
      dataList: [
        {
          id: 1,
          surname: "Eshmanov",
          status: "WebDeveloper",
        },
        {
          id: 2,
          surname: "Murodov",
          status: "WebDeveloper",
        },
        {
          id: 3,
          surname: "Toshmatov",
          status: "WebDeveloper",
        },
      ],
    };
  }

  render() {
      const increment = () => {
      this.setState({
        count: this.state.count + 1,
      });
      console.log("increment");
    };

    const decrement = () => {
      this.setState({
        count: this.state.count - 1,
      });
      console.log("decrement");
    };

    const onchange = (e) => {
      this.setState({
        name: e.target.value,
      });
      console.log(e.target.value);
    };

      return (
        <div>
          <button onClick={() => increment(2)}>
            <h1>+</h1>
          </button>
          <h1>Number {this.state.count}</h1>
          <button onClick={() => decrement(2)}>
            <h1>-</h1>
          </button>

          <br />

          <input onChange={onchange} type="text"></input>
          <h1>name : {this.state.name}</h1>

        </div>
      );
    };
  }


export default Container;
