import React from 'react';
import ReactDOM from 'react-dom';
// import Container from './Components/IncremDecrem/Container';
import './index.css';
// import App from './Components/Card/App';
import Table from './Components/TableHuma/Table';



ReactDOM.render(
  <React.StrictMode>

    {/* <App name= "Eldor"/> */}
    {/* <Container/> */}
    <Table/>
  </React.StrictMode>,
  document.getElementById('root')
);

